const toAbsoluteUrl = pathname => process.env.PUBLIC_URL + pathname;

export default toAbsoluteUrl;
