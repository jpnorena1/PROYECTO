import React from "react";
import { Table } from "reactstrap";

export const RecetaPDF = React.forwardRef(
  ({ diagnosticForm, medicamentosAct }, ref) => {
    return (
      <div ref={ref} style={{ width: "100%" }}>
        <div>
          {/*Aqui se debe colocar el enlace al logo o imagen */}
          <img
            style={{ width: "150px" }}
            src="https://png.pngtree.com/template/20190515/ourlarge/pngtree-abstract-blue-green-hospital-logo-design-image_154200.jpg"
            alt="Logo"
          />
        </div>
        <Table id="esmiTd">
          <thead>
            <tr>
              <th>No.</th>
              <th>MEDICAMENTO</th>
              <th>INDICACIONES</th>
              <th>FRECUENCIA</th>
            </tr>
          </thead>

          <tbody>
            {diagnosticForm.medicamentos.map((medicamento, index) => {
              const medicamentoData = medicamentosAct.find(
                (m) =>
                  parseInt(m.medicamentoId) ===
                  parseInt(medicamento.medicamentoId)
              );
              return (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{medicamentoData.nombreMedicamento}</td>
                  <td>{medicamento.indicaciones}</td>
                  <td>{medicamento.frecuencia}</td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </div>
    );
  }
);
