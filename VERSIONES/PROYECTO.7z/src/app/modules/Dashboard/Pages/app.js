const edad = 22;

function nuevoFuncion(str) {
  let nuevaVariable = edad;
  nuevaVariable = str;
  console.log(nuevaVariable);
  return nuevaVariable;
}
nuevoFuncion("Hola");
