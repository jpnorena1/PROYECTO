export { default as AuthPage } from "./pages/AuthPage";
export { default as Logout } from "./pages/Logout";
export { default as SignupAdministrador } from "./pages/SignupAdministrador";
export { default as SignupAuxiliar } from "./pages/SignupAuxiliar";
export { default as SignupMedic } from "./pages/SignupMedic";
