
const { getQuery, findQuery, type, save, remove } = require('../../core/model');

const USER_ROLES = {
    rider: 'rider',
    driver: 'driver'
};

const USER_LANGUAGES = {
    es: 'es',
    en: 'en'
};

exports.userEntity = {
userId: type.number,
    firstName: type.string,
    lastName: type.string,
    password: type.string,
    nameUser: type.string,
    email: type.string,
    identificacion: type.string,
    phoneNumber: type.string,
    addres: type.string,
    country: type.string,
    dateBirth: type.string,
    sex:type.string,
    role: type.string,
    reservaCita: type.number,
    fullName: { entity: user => [user.firstName, user.lastName].filter(Boolean).join(' ') },
    phone: { entity: user => [user.phoneCountryCode, user.phoneNumber].filter(Boolean).join('') },
    settings: type.entity({
        language: type.enum(USER_LANGUAGES),
    }),
    role: type.enum(USER_ROLES),
    isRider: { entity: user => user.role === USER_ROLES.rider },
    isDriver: { entity: user => user.role === USER_ROLES.driver },
    authCode: type.string,
}


module.exports.findAllUsers = async () => await findQuery('SELECT * FROM USER', [], this.userEntity);

module.exports.getUserByUserId = async userId => await getQuery('SELECT * FROM USER WHERE USER_ID=?', [userId], this.userEntity);

module.exports.saveUser = async user => await save('USER', user, { userId: user.userId }, this.userEntity);

module.exports.getUserByPhone = async ({ nameUser, password }) => await getQuery('SELECT * FROM USERS WHERE NAME_USER=? AND PASSWORD=? ', [nameUser, password], this.userEntity);

module.exports.saveUserByPhone = async user => await save('USERS', user, {  firstName:user.firstName,
            lastName: user.lastname,
            password: user.password,
            email: user.email,
            identificacion: user.identificacion,
            addres: user.addres,
            country: user.country,
            dateBirth: user.dateBirth,
            sex: user.sex,
            phoneNumber: user.phoneNumber,  
            nameUser: user.nameUser, role:user.role }, this.userEntity);
            

module.exports.removeUser = async user => await remove('USER', user, { userId: user.userId }, this.userEntity);